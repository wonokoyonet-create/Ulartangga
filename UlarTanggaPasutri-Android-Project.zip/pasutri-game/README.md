# Ular Tangga Pasutri — Android Studio Project

Aplikasi game offline untuk dua pemain dalam satu perangkat Android.

## Fitur
- Papan ular tangga 1–100, dadu, pion Suami dan Istri.
- Tangga, ular, skor, giliran, kondisi menang, dan mulai ulang.
- Kartu tantangan romantis, lucu, komunikasi, dan intim dewasa yang opsional.
- Lewati tantangan tanpa penalti; tantangan dapat diganti.
- Web game dibundel di `app/src/main/assets/index.html`, sehingga gameplay tidak membutuhkan internet.

## Build APK
1. Ekstrak ZIP.
2. Buka Android Studio → **Open** → pilih folder `UlarTanggaPasutri`.
3. Pastikan Android SDK Platform 35 terpasang dan koneksi tersedia untuk mengunduh Gradle/Android Gradle Plugin jika belum ada.
4. Tunggu Gradle Sync selesai.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Persyaratan
- Android Studio yang mendukung Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.

Catatan: paket ini adalah source project. APK belum dibangun atau diuji pada perangkat Android di lingkungan pembuat file ini. Sebelum rilis, lakukan build dan uji di Android Studio/perangkat nyata.
